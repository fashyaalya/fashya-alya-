<html>

<head>
    <title> Latihan 1 </title>
</head>

<body>
    Halo Kawan.. Yuk kita belajar web programming..!!!<br>
    Nilai 1 = <?= $nilai1; ?> <br>
    Nilai 2 = <?= $nilai2; ?> <br>
    ini hasil dari pemodelan dengan methode penjumlahan yaitu <?= $nilai1 . " + " .
                                                                    $nilai2 . " = " . $hasil; ?>
</body>

</html>